# __init__.py

from .conversor import ConversorBinario
